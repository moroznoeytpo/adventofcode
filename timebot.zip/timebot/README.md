# Timebot
Based on telebot https://github.com/KyleJamesWalker/telebot

## Installation
Run next command in terminal:
```bash
git clone git@gitlab.kodeks.ru:avc/timebot.git
cd timebot
```

Make sure, that you already install `docker` 
or use [instruction](https://gitlab.kodeks.ru/kodeks/guidelines/blob/master/docker/install.md)

If `docker` and `docker-compose` is correct installed, run command in terminal:
```bash
docker-compose up -d
```
Now add `@punctualbot` to your friend list in Telegram, and send some command to him.

## Commands
**help** - Get help. \
**start** - Start work time. \
**end** - Time to go home. \
**total** - Calculate work time by month.

### start
Save to DB information of entering to office
```json
{
  "user_id": 1,  // current user id who send request
  "message": "start",  // type of message
  "created_at": "2020-01-01 12:00:00" // request time
}
```
### end
Save to DB information of ending work day
```json
{
  "user_id": 1,  // current user id who send request
  "message": "end",  // type of message
  "created_at": "2020-01-01 12:00:00" // request time
}
```

### total
Get information about total time by period
**Response**
