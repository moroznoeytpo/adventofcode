from sqlalchemy import Column, Integer, Text
from core.models import Base


class EventsModel(Base):
    __tablename__ = 'events'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    event = Column(Text)
    created_at = Column(Text)

    def __init__(self, user_id: int, event: str, created_at):
        """
        Save event to DB.

        Args:
            user_id: ID of telegram user
            event: Event name
            created_at (datetime.datetime): Date of event saving
        """
        self.user_id = user_id
        self.event = event
        self.created_at = created_at
