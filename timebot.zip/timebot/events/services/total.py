import os
import re
from datetime import datetime
from dateutil.relativedelta import relativedelta

from core.models import session
from events.models import EventsModel
from events.exceptions import IncorrectDateFormat, NoMatchEvents
from .base import BaseEvents


class TotalEvents(BaseEvents):
    def __init__(self, user_id: int, date: str = None):
        """
        Args:
            user_id: ID of telegram user
            date: Date of event saving
        """
        super().__init__(user_id, date)
        self.start_date = None
        self.end_date = None
        self.min_date = None

        self.events = {}

    def set_dates(self) -> None:
        if self.date:
            date_match = re.search(r"(\d{4})?.*?(\d{2})", self.date, flags=re.DOTALL)
            if not date_match:
                raise IncorrectDateFormat('month')
            elif not date_match[1]:
                self.date = f"{self.today.year}-{date_match[2]}"
            else:
                self.date = f"{date_match[1]}-{date_match[2]}"
            self.current_date = datetime.strptime(self.date, '%Y-%m')
        else:
            self.current_date = self.today

        self.next_date = self.current_date + relativedelta(months=1)
        self.start_date = os.getenv('DEFAULT_START_TIME', '10:00').split(':')
        self.end_date = os.getenv('DEFAULT_END_TIME', '18:30').split(':')
        self.min_date = os.getenv('MIN_WORK_TIME', '8:30').split(':')

    def set_query(self) -> None:
        self.query = session.query(EventsModel) \
            .filter(EventsModel.user_id == self.user_id) \
            .filter(EventsModel.created_at >= self.current_date.strftime('%Y-%m-01'),
                    EventsModel.created_at < self.next_date.strftime('%Y-%m-01')) \
            .order_by(EventsModel.id)

    def collect_events(self):
        if not self.query.count():
            raise NoMatchEvents(self.current_date)

        # Collect days events
        for item in self.query.all():
            created_at = item.created_at
            event = item.event

            day = created_at.strftime('%Y-%m-%d')
            if not self.events.get(day):
                self.events[day] = {event: {}}
            self.events[day][event] = {
                'timestamp': created_at.hour * 60 + created_at.minute,
                'time': created_at.strftime('%H:%M')
            }
        # Add missing events
        for item in self.events.values():
            if not item.get('start'):
                item['start'] = {
                    'timestamp': int(self.start_date[0]) * 60 + int(self.start_date[1]),
                    'time': f"{self.start_date[0]}:{self.start_date[1]}"
                }
            if not item.get('end'):
                item['end'] = {
                    'timestamp': int(self.end_date[0]) * 60 + int(self.end_date[1]),
                    'time': f"{self.end_date[0]}:{self.end_date[1]}"
                }

    def collect_response(self):
        total = 0
        diff_total = 0
        response = []
        for day, events in self.events.items():
            if events['start']['timestamp'] > events['end']['timestamp']:
                response.append(
                    f"{day}:"
                    f"\t\t\t|\t\t\tincorrect date"
                    f"\t\t\t|\t\t\t{events['start']['time']} - {events['end']['time']}"
                )
                continue

            day_total = events['end']['timestamp'] - events['start']['timestamp']
            day_diff_total = day_total - (int(self.min_date[0]) * 60 + int(self.min_date[1]))
            total += day_total
            diff_total += day_diff_total

            if day_diff_total < 0:
                sign = '-'
                day_diff_total = -day_diff_total
            else:
                sign = ''
            response.append(
                f"{day}"
                f"\t\t\t|\t\t\t{sign}{day_diff_total // 60}h {day_diff_total % 60}m"
                f"\t\t\t|\t\t\t{day_total // 60}h {day_total % 60}m"
                f"\t\t\t|\t\t\t{events['start']['time']} - {events['end']['time']}"
            )
        else:
            if diff_total < 0:
                sign = '-'
                diff_total = -diff_total
            else:
                sign = '+'
            response.append('-' * 70)
            response.append(
                f"{self.current_date.strftime('%Y-%m')}"
                f"\t\t\t|\t\t\t{sign}{diff_total // 60}h {diff_total % 60}m"
                f"\t\t\t|\t\t\t{total // 60}h {total % 60}m"
            )
        self.response = "\n".join(response)

    def execute(self) -> None:
        """Save event to DB."""
        self.set_dates()
        self.set_query()
        self.collect_events()
        self.collect_response()
