import re
from datetime import datetime
from dateutil.relativedelta import relativedelta

from core.models import session
from events.models import EventsModel
from events.exceptions import IncorrectDateFormat, AlreadyAddedEvent
from .base import BaseEvents


class AddEvents(BaseEvents):
    def __init__(self, user_id: int, event: str, date: str = None):
        """
        Args:
            user_id: ID of telegram user
            event: Event name
            date: Date of event saving
        """
        super().__init__(user_id, date)
        self.event = event
        self.rewrite_date = False

    def set_dates(self) -> None:
        if self.date:
            date_match = re.search(r"(\d{4}-\d{2}-\d{2})?.*?(\d{1,2}:\d{2})", self.date, flags=re.DOTALL)
            if not date_match:
                raise IncorrectDateFormat('day')
            elif not date_match[1]:
                self.date = f"{self.today.strftime('%Y-%m-%d')} {date_match[2]}"
            else:
                self.date = f"{date_match[1]} {date_match[2]}"
            self.rewrite_date = True
            self.current_date = datetime.strptime(self.date, '%Y-%m-%d %H:%M')
        else:
            self.current_date = self.today

        self.next_date = self.current_date + relativedelta(days=1)

    def set_query(self) -> None:
        self.query = session.query(EventsModel) \
            .filter(EventsModel.user_id == self.user_id) \
            .filter(EventsModel.event == self.event) \
            .filter(EventsModel.created_at > self.current_date.strftime('%Y-%m-%d'),
                    EventsModel.created_at < self.next_date.strftime('%Y-%m-%d'))

    def collect_response(self) -> None:
        if not self.query.count():
            obj = EventsModel(self.user_id, self.event, self.current_date)
            session.add(obj)
            session.commit()
            self.response = f"Add {self.event.upper()} at {self.current_date}"
        elif self.rewrite_date:
            self.query.update({EventsModel.created_at: self.current_date})
            session.commit()
            self.response = f"Rewrite {self.event.upper()} at {self.current_date}"
        else:
            session.rollback()
            raise AlreadyAddedEvent(self.event, self.current_date)

    def execute(self) -> None:
        """Save event to DB."""
        self.set_dates()
        self.set_query()
        self.collect_response()
