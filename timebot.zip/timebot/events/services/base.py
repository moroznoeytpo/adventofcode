from abc import ABC, abstractmethod
from datetime import datetime

from dateutil.relativedelta import relativedelta
from events.exceptions import IncorrectDateFormat, AlreadyAddedEvent, NoMatchEvents


class BaseEvents(ABC):
    def __init__(self, user_id: int, date: str = None):
        """
        Args:
            user_id: ID of telegram user
            date: Date of event saving
        """
        self.user_id = user_id
        self.date = date
        self.today = datetime.now() + relativedelta(hours=3)

        self.current_date = None
        self.next_date = None

        self.query = None
        self.response = ""

    @abstractmethod
    def set_dates(self) -> None:
        pass

    @abstractmethod
    def set_query(self) -> None:
        pass

    @abstractmethod
    def collect_response(self):
        pass

    @abstractmethod
    def execute(self):
        pass

    def send(self):
        try:
            self.execute()
        except (IncorrectDateFormat, AlreadyAddedEvent, NoMatchEvents) as exc:
            self.response = exc
        except Exception as exc:
            self.response = f"Unknown error {exc}"
