class IncorrectDateFormat(Exception):
    def __init__(self, type: str):
        """
        Args:
            type:
        """
        if type == 'day':
            self.format = {
                'Y-m-d H:M': '2020-01-01 10:30',
                'H:M': '10:30'
            }
        elif type == 'month':
            self.format = {
                'Y-m': '2020-01',
                'm': '01'
            }
        else:
            raise KeyError('unknown type')

    def __str__(self):
        response = ["Incorrect date format."]
        response += ['\nYou must use one of next format for add:']
        response += [f"\t\t* {item}" for item in self.format.keys()]
        response += ['\nExample:']
        response += [f"\t\t* {item}" for item in self.format.values()]
        return "\n".join(response)


class AlreadyAddedEvent(Exception):
    def __init__(self, event: str, date):
        """
        Args:
            event:
            date datetime.datetime:
        """
        self.event = event
        self.date = date

    def __str__(self):
        response = [
            f"Already added {self.event.upper()} to {self.date.strftime('%Y-%m-%d')}.",
            "\nYou must use one of next format for rewrite:",
            "\t\t* Y-m-d H:M",
            "\t\t* H:M (set current Y-m-d by default)",
            "\nExample:",
            "\t\t* 2020-01-01 10:30",
            "\t\t* 10:30"
        ]
        return "\n".join(response)


class NoMatchEvents(Exception):
    def __init__(self, date):
        """
        Args:
            date datetime.datetime:
        """
        self.date = date

    def __str__(self):
        response = [
            f"No match list of events at {self.date.strftime('%Y-%m')}.",
            f"\nYou can add event by passing",
            f"/start  {self.date.strftime('%Y-%m-%d %H:%M')}",
            f"/end  {self.date.strftime('%Y-%m-%d %H:%M')}"
        ]
        return "\n".join(response)
