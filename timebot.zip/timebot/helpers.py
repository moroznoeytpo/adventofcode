from core.models import session
from core.events import Events


@classmethod
def save(cls, user_id: int, event: str):
    """
    Save event to DB.

    Args:
        user_id: ID of telegram user
        event: Event name
    """
    obj = cls(user_id, event)
    session.add(obj)
    session.commit()
