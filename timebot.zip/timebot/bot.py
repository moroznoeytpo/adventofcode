import os
import dotenv
from telebot import TeleBot
from events.services.add import AddEvents
from events.services.total import TotalEvents
from core.bot import Bot

app = TeleBot(__name__)


@app.route('/start ?(.*)')
def start(message: dict, date: str = ""):
    """
    Start work time.

    Args:
        message: Message info
        date: Enter date
    """
    bot_obj = Bot(message)
    event_obj = AddEvents(bot_obj.user_id, 'start', date)
    event_obj.send()
    app.send_message(bot_obj.chat_id, event_obj.response)


@app.route('/end ?(.*)')
def end(message: dict, date: str = ""):
    """
    Time to go home.

    Args:
        message: Message info
        date: Enter date
    """
    bot_obj = Bot(message)
    event_obj = AddEvents(bot_obj.user_id, 'end', date)
    event_obj.send()
    app.send_message(bot_obj.chat_id, event_obj.response)


@app.route('/total ?(.*)')
def total(message: dict, date: str = ""):
    """
    Calculate work time by (week, month, year)

    Args:
        message: Message info
        date: Total month
    """
    bot_obj = Bot(message)
    event_obj = TotalEvents(bot_obj.user_id, date)
    event_obj.send()
    app.send_message(bot_obj.chat_id, event_obj.response)


if __name__ == '__main__':
    dotenv.load_dotenv('.env')
    app.config['api_key'] = os.getenv('BOT_TOKEN')
    app.poll(debug=True)
