"""create events table

Revision ID: cc9e5c3cb236
Revises: 
Create Date: 2020-01-29 10:52:31.595759

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cc9e5c3cb236'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'events',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.Integer),
        sa.Column('event', sa.Text(50), nullable=False),
        sa.Column('created_at', sa.DateTime()),
    )


def downgrade():
    op.drop_table('events')
