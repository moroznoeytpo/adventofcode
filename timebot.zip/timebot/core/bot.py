class Bot:
    def __init__(self, message: dict):
        """
        Args:
            message: Message info from telebot
        """
        self.message = message
        self.user_id = message['from']['id']
        self.chat_id = message['chat']['id']
