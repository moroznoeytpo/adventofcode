# coding=utf-8
import os
import dotenv

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Load end variables
BASE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
dotenv.load_dotenv(dotenv_path=os.path.join(BASE_DIR, '.env'))

# Configure postgres engine
database_url = f"postgresql://" \
               f"{os.getenv('BOT_DB_USER')}:{os.getenv('BOT_DB_PASS')}" \
               f"@{os.getenv('BOT_DB_HOST')}:{os.getenv('BOT_DB_PORT')}" \
               f"/{os.getenv('BOT_DB_NAME')}"
engine = create_engine(database_url)
Base = declarative_base()

# Generate database schema
Base.metadata.create_all(engine)

# Create a new session
Session = sessionmaker(bind=engine)
session = Session()
